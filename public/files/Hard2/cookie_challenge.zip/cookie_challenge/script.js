// flag を Cookie に書き込む
document.cookie = "flag=flag{cookie_is_sweet}; path=/";

import http.server
import socketserver
import os

PORT = 8000

class QuietHandler(http.server.SimpleHTTPRequestHandler):
    def list_directory(self, path):
        self.send_error(403, "Directory listing is not allowed")
        return None

    def translate_path(self, path):
        # 通常は public ディレクトリ内を公開
        root = os.path.join(os.getcwd(), 'public')
        rel_path = path.lstrip('/')

        # secret ディレクトリのみ特例で許可
        if rel_path.startswith('secret/'):
            return os.path.join(os.getcwd(), rel_path)
        return os.path.join(root, rel_path)

with socketserver.TCPServer(("", PORT), QuietHandler) as httpd:
    print(f"Server running on http://localhost:{PORT}")
    httpd.serve_forever()

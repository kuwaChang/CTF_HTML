# CTF Challenge: Secure Memo

ようこそ！これは安全なメモアプリケーションです。
あなたのメモは他の人から見られることはありません...本当にそうでしょうか？

## 問題の概要

社内向けに開発された「Secure Memo」アプリケーションがあります。
このアプリのどこかに隠されたFLAGを見つけ出してください。

## セットアップ手順

1.  このフォルダを解凍します。
2.  ターミナル（コマンドプロンプト）を開き、このフォルダに移動します。
    ```sh
    cd path/to/web5
    ```
3.  (推奨) Pythonの仮想環境を作成し、有効化します。
    ```sh
    # Windowsの場合
    python -m venv venv
    venv\Scripts\activate

    # Mac/Linuxの場合
    python3 -m venv venv
    source venv/bin/activate
    ```
4.  必要なライブラリをインストールします。
    ```sh
    pip install -r requirements.txt
    ```
5.  ローカルサーバーを起動します。
    ```sh
    python app.py
    ```
6.  ターミナルに `* Running on http://127.0.0.1:5000` のような表示が出たら、Webブラウザで [http://127.0.0.1:5000](http://127.0.0.1:5000) にアクセスしてください。

## ログイン情報

テスト用のアカウントが用意されています。
-   **ユーザー名:** `guest`
-   **パスワード:** `guest`

## 注意事項

**この問題の意図を理解し、`app.py` などのソースコードを直接見ずに解いてみてください。**

Good Luck!
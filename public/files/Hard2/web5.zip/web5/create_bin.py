from flask import Flask, render_template, request, redirect, url_for, session, abort

app = Flask(__name__)
# セッションを暗号化するためのキー。CTFなので固定でOK
app.secret_key = 'super_secret_key_for_ctf_session'

# --- データベースの代わりとなるデータ ---
# ユーザーIDをキーとする辞書
USERS = {
    '1': {'username': 'admin', 'password': 'ThisPasswordIsSuperHardToGuess123!'},
    '2': {'username': 'guest', 'password': 'guest'}
}

MEMOS = {
    '1': '管理者メモ: FLAG{1DOR_1s_Simpl3_but_P0werfu1}',
    '2': 'ゲスト用メモ: 明日の10時にミーティング。'
}
# ------------------------------------

@app.route('/')
def index():
    # ログインしていなければログインページへ
    if 'user_id' not in session:
        return redirect(url_for('login'))
    # ログインしていれば自分のメモページへ
    return redirect(url_for('show_memo', user_id=session['user_id']))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # ユーザーを検索
        for user_id, user_data in USERS.items():
            if user_data['username'] == username and user_data['password'] == password:
                # ログイン成功
                session['user_id'] = user_id
                session['username'] = user_data['username']
                return redirect(url_for('show_memo', user_id=user_id))
        
        # ログイン失敗
        return render_template('login.html', error="ユーザー名またはパスワードが違います。")

    return render_template('login.html')

@app.route('/memo')
def show_memo():
    # ログインしているかだけをチェック
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    # URLからuser_idを取得
    requested_user_id = request.args.get('user_id')

    if not requested_user_id:
        abort(400, "User ID is required.")

    # ▼▼▼▼▼ ここが脆弱性のポイント ▼▼▼▼▼
    # 本来は requested_user_id と session['user_id'] が一致するか確認すべきだが、
    # そのチェックを行わずにメモを取得してしまう。
    memo_content = MEMOS.get(requested_user_id, "指定されたユーザーのメモはありません。")
    # ▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲

    # 表示するユーザー名を取得（見栄えのため）
    display_username = USERS.get(requested_user_id, {}).get('username', 'Unknown User')

    return render_template('memo.html', username=display_username, memo=memo_content)

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

if __name__ == '__main__':
    # debug=False にして、参加者がデバッガを使えないようにする
    app.run(host='0.0.0.0', port=5000, debug=False)